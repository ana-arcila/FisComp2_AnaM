#include <iostream>
#include <cmath>
using namespace std;

class Cuadrados{
    private:
        float Lado;

    public:
        Cuadrados(float);
        float Area();
        float Perimetro();
};